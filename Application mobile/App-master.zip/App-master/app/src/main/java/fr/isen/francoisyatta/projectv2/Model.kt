package fr.isen.francoisyatta.projectv2

import android.icu.text.CaseMap.Title

class Model (val title: String, val des: String, val image: Int) {
}