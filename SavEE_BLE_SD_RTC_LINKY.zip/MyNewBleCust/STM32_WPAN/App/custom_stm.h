/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    App/custom_stm.h
  * @author  MCD Application Team
  * @brief   Header for custom_stm.c module.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef CUSTOM_STM_H
#define CUSTOM_STM_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "custom_app.h"
#include "common_blesvc.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
typedef enum
{
  /* MyServ */
  CUSTOM_STM_S1_CHAR1,
  CUSTOM_STM_S1_CHAR2,
  CUSTOM_STM_S1_CHAR3,
  CUSTOM_STM_S1_CHAR4,
} Custom_STM_Char_Opcode_t;

typedef enum
{
  /* S1_CHAR1 */
  CUSTOM_STM_S1_CHAR1_READ_EVT,
  CUSTOM_STM_S1_CHAR1_WRITE_NO_RESP_EVT,
  CUSTOM_STM_S1_CHAR1_NOTIFY_ENABLED_EVT,
  CUSTOM_STM_S1_CHAR1_NOTIFY_DISABLED_EVT,
  /* S1_CHAR2 */
  CUSTOM_STM_S1_CHAR2_READ_EVT,
  CUSTOM_STM_S1_CHAR2_WRITE_NO_RESP_EVT,
  CUSTOM_STM_S1_CHAR2_NOTIFY_ENABLED_EVT,
  CUSTOM_STM_S1_CHAR2_NOTIFY_DISABLED_EVT,
  /* S1_CHAR3 */
  CUSTOM_STM_S1_CHAR3_READ_EVT,
  CUSTOM_STM_S1_CHAR3_WRITE_NO_RESP_EVT,
  CUSTOM_STM_S1_CHAR3_NOTIFY_ENABLED_EVT,
  CUSTOM_STM_S1_CHAR3_NOTIFY_DISABLED_EVT,
  /* S1_CHAR4 */
  CUSTOM_STM_S1_CHAR4_READ_EVT,
  CUSTOM_STM_S1_CHAR4_WRITE_NO_RESP_EVT,
  CUSTOM_STM_S1_CHAR4_NOTIFY_ENABLED_EVT,
  CUSTOM_STM_S1_CHAR4_NOTIFY_DISABLED_EVT,
  CUSTOM_STM_S1_CHAR4_INDICATE_ENABLED_EVT,
  CUSTOM_STM_S1_CHAR4_INDICATE_DISABLED_EVT,

  CUSTOM_STM_BOOT_REQUEST_EVT
} Custom_STM_Opcode_evt_t;

typedef struct
{
  uint8_t * pPayload;
  uint8_t   Length;
} Custom_STM_Data_t;

typedef struct
{
  Custom_STM_Opcode_evt_t       Custom_Evt_Opcode;
  Custom_STM_Data_t             DataTransfered;
  uint16_t                      ConnectionHandle;
  uint8_t                       ServiceInstance;
} Custom_STM_App_Notification_evt_t;

/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
extern uint8_t SizeS1_Char1;
extern uint8_t SizeS1_Char2;
extern uint8_t SizeS1_Char3;
extern uint8_t SizeS1_Char4;

/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* External variables --------------------------------------------------------*/
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/* Exported macros -----------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions ------------------------------------------------------- */
void SVCCTL_InitCustomSvc(void);
void Custom_STM_App_Notification(Custom_STM_App_Notification_evt_t *pNotification);
tBleStatus Custom_STM_App_Update_Char(Custom_STM_Char_Opcode_t CharOpcode,  uint8_t *pPayload);
/* USER CODE BEGIN EF */
tBleStatus Custom_Characteristic_Send(Custom_STM_Char_Opcode_t CharOpcode, uint8_t *pPayload,uint8_t Length,uint8_t Offset);
void SEND_MES_BLESTATUS(tBleStatus Status);
void MirrorToC2(uint8_t *pPayload,uint8_t Length);
void WhatWantMobile(uint8_t *pPayload,uint8_t Length);
void C1_NOTIFICATION(uint8_t *Data,uint8_t Size);
void C2_NOTIFICATION(uint8_t *Data,uint8_t Size);
void C3_NOTIFICATION(uint8_t *Data,uint8_t Size);
void C4_NOTIFICATION(uint8_t *Data,uint8_t Size);
void My_Action(void);
void Ask_My_Action(void);
/* USER CODE END EF */

#ifdef __cplusplus
}
#endif

#endif /*CUSTOM_STM_H */
