/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "app_fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BUFFERSIZE 27
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
IPCC_HandleTypeDef hipcc;

UART_HandleTypeDef hlpuart1;
UART_HandleTypeDef huart1;
DMA_HandleTypeDef hdma_lpuart1_rx;
DMA_HandleTypeDef hdma_usart1_rx;
DMA_HandleTypeDef hdma_usart1_tx;

RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim17;

PCD_HandleTypeDef hpcd_USB_FS;

/* USER CODE BEGIN PV */
//Linky part -- buffer pour stocker les données du linky
uint8_t MyRxBuff[805];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USB_PCD_Init(void);
static void MX_IPCC_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM17_Init(void);
static void MX_SPI1_Init(void);
static void MX_LPUART1_UART_Init(void);
static void MX_RF_Init(void);
/* USER CODE BEGIN PFP */
uint8_t My_Value_Spy[30];
uint8_t TimerCount[3];

//Linky part
uint8_t GlobI;

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t SPI_TX[100];
uint8_t SPI_RX[100];
void SD_ERROR_Check(FRESULT res)
{
	switch (res)
	{
	case FR_OK :
		APP_DBG_MSG("0: Succeeded\n");
		break;

	case FR_DISK_ERR :
		APP_DBG_MSG("1: A hard error occurred in the low level disk I/O layer\n");
		break;

	case FR_INT_ERR :
		APP_DBG_MSG("2:  Assertion failed\n");
		break;

	case FR_NOT_READY :
		APP_DBG_MSG("3: The physical drive cannot work\n");
		break;

	case FR_NO_FILE :
		APP_DBG_MSG("4: Could not find the file\n");
		break;

	case FR_NO_PATH :
		APP_DBG_MSG("(5) Could not find the path\n");
		break;

	case FR_INVALID_NAME :
		APP_DBG_MSG("(6) The path name format is invalid\n");
		break;

	case FR_DENIED :
		APP_DBG_MSG("(7) Access denied due to prohibited access or directory full\n");
		break;

	case FR_EXIST :
		APP_DBG_MSG("(8) Access denied due to prohibited access\n");
		break;

	case FR_INVALID_OBJECT :
		APP_DBG_MSG("(9) The file/directory object is invalid\n");
		break;

	case FR_WRITE_PROTECTED :
		APP_DBG_MSG(" (10) The physical drive is write protected\n");
		break;

	case FR_INVALID_DRIVE :
		APP_DBG_MSG("(11) The logical drive number is invalid\n");
		break;

	case FR_NOT_ENABLED :
		APP_DBG_MSG("(12) The volume has no work area\n");
		break;

	case FR_NO_FILESYSTEM :
		APP_DBG_MSG("(13) There is no valid FAT volume\n");
		break;

	case FR_MKFS_ABORTED :
		APP_DBG_MSG("(14) The f_mkfs() aborted due to any problem\n");
		break;

	case FR_TIMEOUT :
		APP_DBG_MSG(" (15) Could not get a grant to access the volume within defined period\n");
		break;

	case FR_LOCKED :
		APP_DBG_MSG("(16) The operation is rejected according to the file sharing policy\n");
		break;

	case FR_NOT_ENOUGH_CORE :
		APP_DBG_MSG("(17) LFN working buffer could not be allocated\n");
		break;

	case FR_TOO_MANY_OPEN_FILES :
		APP_DBG_MSG("(18) Number of open files > _FS_LOCK\n");
		break;

	case FR_INVALID_PARAMETER :
		APP_DBG_MSG(" (19) Given parameter is invalid\n");
		break;
	}
}

void SDCard_Writting(uint8_t readBuf[]){
	  printf("\r\n~ SD card ~\r\n\r\n");

	   HAL_Delay(1000); //a short delay is important to let the SD card settle

	   //some variables for FatFs
	   FATFS FatFs; 	//Fatfs handle
	   FIL fil; 		//File handle
	   FRESULT fres; //Result after operations

	   //Open the file system
	   fres = f_mount(&FatFs, "", 1); //1=mount now
	   if (fres != FR_OK) {
	 	printf("f_mount error (%i)\r\n", fres);
	 	while(1);
	   }

	   //Write a file "linky.txt"
	   fres = f_open(&fil, "linky.txt", FA_WRITE | FA_OPEN_ALWAYS | FA_CREATE_ALWAYS);
	   if(fres == FR_OK) {
	 	printf("I was able to open 'linky.txt' for writing\r\n");
	   } else {
	 	printf("f_open error (%i)\r\n", fres);
	   }

	   //Copy a string
	   UINT bytesWrote;
	   fres = f_write(&fil, readBuf, 805, &bytesWrote);
	   if(fres == FR_OK) {
	 	printf("Wrote %i bytes to 'linky.txt'!\r\n", bytesWrote);
	   } else {
	 	printf("f_write error (%i)\r\n",fres);
	   }

	   //close file
	   f_close(&fil);
	   printf("Close file\r\n");

	   //demount the SD card
	   f_mount(NULL, "", 0);
	   printf("Demount\r\n");
}

//Fonction pour le RTC, on récupère l'heure du mobile qui écrit dans la caractéristique 4
void set_time(uint8_t Clock[6])
{
	RTC_TimeTypeDef sTime = {0};
	RTC_DateTypeDef sDate = {0};

	/** Initialize RTC and set the Time and Date
      */
	sTime.Hours = Clock[3];
	sTime.Minutes = Clock[4];
	sTime.Seconds = Clock[5];
	sTime.SubSeconds = 0x0;
	sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
	sTime.StoreOperation = RTC_STOREOPERATION_RESET;
	if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK){Error_Handler();}

	sDate.Month = Clock[1];
	sDate.Date = Clock[2];
	sDate.Year = Clock[0];

	if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
	{
	Error_Handler();
	}
	/* USER CODE BEGIN RTC_Init 2 */
	HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR1, 0x32F2);
	/* USER CODE END RTC_Init 2 */
}

void get_time(void)
{
	RTC_DateTypeDef gDate;
	RTC_TimeTypeDef gTime;

	/* Get the RTC current Time */
	HAL_RTC_GetTime(&hrtc, &gTime, RTC_FORMAT_BIN);
	/* Get the RTC current Date */
	HAL_RTC_GetDate(&hrtc, &gDate,RTC_FORMAT_BIN);

}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	 FATFS *fs;     /* Ponter to the filesystem object */
	 FRESULT RESULT;
	 fs = malloc(sizeof (FATFS));           /* Get work area for the volume */

	 //Initialisation de la "fausse" heure qu'on envoie dans le TIMERIRQ
	 TimerCount[0]=12;
	 TimerCount[1]=58;
	 TimerCount[2]=45;

	 //Linky part
	 GlobI = 0;


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
  /* Config code for STM32_WPAN (HSE Tuning must be done before system clock configuration) */
  MX_APPE_Config();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

/* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* IPCC initialisation */
  MX_IPCC_Init();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USB_PCD_Init();
  MX_RTC_Init();
  MX_TIM17_Init();
  MX_SPI1_Init();
  if (MX_FATFS_Init() != APP_OK) {
    Error_Handler();
  }
  MX_LPUART1_UART_Init();
  MX_RF_Init();
  /* USER CODE BEGIN 2 */
  MX_USART1_UART_Init();
  Set_LED('A');
  char *msg= "Hello Nucleo !\n\r";

  //Linky part
  HAL_UART_Receive_IT(&hlpuart1, MyRxBuff, 805); //Receive the data from Linky
  SDCard_Writting(MyRxBuff); //on écrit les trames dans un fichier sur la carte SD

  /* USER CODE END 2 */

  /* Init code for STM32_WPAN */
  MX_APPE_Init();

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 0x100);
  Clear_LED('A');

  //SD_init_Fct();
  while (1)
  {
/*
	 //deactivate the CS pin
	  Disable_SD_CS();

	  // give SD card time to power up
	  HAL_Delay(1);
	  SPI_TX[0]=0xFF;//dummy Byte
	    // send 80 clock cycles to synchronize
	    for(uint8_t i = 0; i < 10; i++)
	    {
	    HAL_SPI_Transmit(&hspi1,SPI_TX,1, 0);
	    }

	    Disable_SD_CS();
	  SPI_TX[0]=0x40;//CMD0
	  SPI_TX[1]=0x00; //0
	  SPI_TX[2]=0x00; //CMD8
	  SPI_TX[3]=0x00; //0
	  SPI_TX[4]=0x00;//0
	  SPI_TX[5]=0x95; //
	  Enable_SD_CS();
	  HAL_SPI_Transmit(&hspi1,SPI_TX,6, 0);
	  Disable_SD_CS();
*/
	  //Linky part
	  if(GlobI==804){
		  GlobI=0;
	  }

    /* USER CODE END WHILE */
    MX_APPE_Process();

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Macro to configure the PLL multiplication factor
  */
  __HAL_RCC_PLL_PLLM_CONFIG(RCC_PLLM_DIV1);

  /** Macro to configure the PLL clock source
  */
  __HAL_RCC_PLL_PLLSOURCE_CONFIG(RCC_PLLSOURCE_MSI);

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE
                              |RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the SYSCLKSource, HCLK, PCLK1 and PCLK2 clocks dividers
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK4|RCC_CLOCKTYPE_HCLK2
                              |RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSE;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.AHBCLK2Divider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLK4Divider = RCC_SYSCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Initializes the peripherals clock
  */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_SMPS|RCC_PERIPHCLK_RFWAKEUP;
  PeriphClkInitStruct.RFWakeUpClockSelection = RCC_RFWKPCLKSOURCE_LSE;
  PeriphClkInitStruct.SmpsClockSelection = RCC_SMPSCLKSOURCE_HSI;
  PeriphClkInitStruct.SmpsDivSelection = RCC_SMPSCLKDIV_RANGE0;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN Smps */

  /* USER CODE END Smps */
}

/**
  * @brief IPCC Initialization Function
  * @param None
  * @retval None
  */
static void MX_IPCC_Init(void)
{

  /* USER CODE BEGIN IPCC_Init 0 */

  /* USER CODE END IPCC_Init 0 */

  /* USER CODE BEGIN IPCC_Init 1 */

  /* USER CODE END IPCC_Init 1 */
  hipcc.Instance = IPCC;
  if (HAL_IPCC_Init(&hipcc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN IPCC_Init 2 */

  /* USER CODE END IPCC_Init 2 */

}

/**
  * @brief LPUART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPUART1_UART_Init(void)
{

  /* USER CODE BEGIN LPUART1_Init 0 */

  /* USER CODE END LPUART1_Init 0 */

  /* USER CODE BEGIN LPUART1_Init 1 */

  /* USER CODE END LPUART1_Init 1 */
  hlpuart1.Instance = LPUART1;
  hlpuart1.Init.BaudRate = 9600;
  hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
  hlpuart1.Init.StopBits = UART_STOPBITS_1;
  hlpuart1.Init.Parity = UART_PARITY_EVEN;
  hlpuart1.Init.Mode = UART_MODE_RX;
  hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  hlpuart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  hlpuart1.FifoMode = UART_FIFOMODE_DISABLE;
  if (HAL_UART_Init(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&hlpuart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&hlpuart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LPUART1_Init 2 */

  /* USER CODE END LPUART1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_8;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief RF Initialization Function
  * @param None
  * @retval None
  */
static void MX_RF_Init(void)
{

  /* USER CODE BEGIN RF_Init 0 */

  /* USER CODE END RF_Init 0 */

  /* USER CODE BEGIN RF_Init 1 */

  /* USER CODE END RF_Init 1 */
  /* USER CODE BEGIN RF_Init 2 */

  /* USER CODE END RF_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = CFG_RTC_ASYNCH_PRESCALER;
  hrtc.Init.SynchPrediv = CFG_RTC_SYNCH_PRESCALER;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 0x0;
  sTime.Minutes = 0x0;
  sTime.Seconds = 0x0;
  sTime.SubSeconds = 0x0;
  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  sDate.WeekDay = RTC_WEEKDAY_MONDAY;
  sDate.Month = RTC_MONTH_JANUARY;
  sDate.Date = 0x1;
  sDate.Year = 0x0;

  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable the WakeUp
  */
  if (HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, 0, RTC_WAKEUPCLOCK_RTCCLK_DIV16) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */
	HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR1, 0x32F2);
  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_128;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM17 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM17_Init(void)
{

  /* USER CODE BEGIN TIM17_Init 0 */

  /* USER CODE END TIM17_Init 0 */

  /* USER CODE BEGIN TIM17_Init 1 */

  /* USER CODE END TIM17_Init 1 */
  htim17.Instance = TIM17;
  htim17.Init.Prescaler = 32000;
  htim17.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim17.Init.Period = 1000;
  htim17.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim17.Init.RepetitionCounter = 0;
  htim17.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim17) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM17_Init 2 */

  /* USER CODE END TIM17_Init 2 */

}

/**
  * @brief USB Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_PCD_Init(void)
{

  /* USER CODE BEGIN USB_Init 0 */

  /* USER CODE END USB_Init 0 */

  /* USER CODE BEGIN USB_Init 1 */

  /* USER CODE END USB_Init 1 */
  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_Init 2 */

  /* USER CODE END USB_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
  /* DMA1_Channel3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD2_Pin|LD3_Pin|LD1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : SD_CS_Pin */
  GPIO_InitStruct.Pin = SD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin LD3_Pin LD1_Pin */
  GPIO_InitStruct.Pin = LD2_Pin|LD3_Pin|LD1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : B2_Pin B3_Pin */
  GPIO_InitStruct.Pin = B2_Pin|B3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*
void SD_init_Fct() {
    FATFS fs;
    FRESULT res;
APP_DBG_MSG("Ready!\r\n");

    // mount the default drive
    res = f_mount(&fs, "", 1);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_mount() failed, res = %d\r\n", res);
        return;
    }

    APP_DBG_MSG("f_mount() done!\r\n");

    uint32_t freeClust;
    FATFS* fs_ptr = &fs;
    res = f_getfree("", &freeClust, &fs_ptr); // Warning! This fills fs.n_fatent and fs.csize!
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_getfree() failed, res = %d\r\n", res);
        return;
    }

    APP_DBG_MSG("f_getfree() done!\r\n");

    uint32_t totalBlocks = (fs.n_fatent - 2) * fs.csize;
    uint32_t freeBlocks = freeClust * fs.csize;

    APP_DBG_MSG("Total blocks: %lu (%lu Mb)\r\n", totalBlocks, totalBlocks / 2000);
    APP_DBG_MSG("Free blocks: %lu (%lu Mb)\r\n", freeBlocks, freeBlocks / 2000);

    DIR dir;
    res = f_opendir(&dir, "/");
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_opendir() failed, res = %d\r\n", res);
        return;
    }

    FILINFO fileInfo;
    uint32_t totalFiles = 0;
    uint32_t totalDirs = 0;
    APP_DBG_MSG("--------\r\nRoot directory:\r\n");
    for(;;) {
        res = f_readdir(&dir, &fileInfo);
        if((res != FR_OK) || (fileInfo.fname[0] == '\0')) {
        	SD_ERROR_Check(res);
            break;
        }

        if(fileInfo.fattrib & AM_DIR) {
            APP_DBG_MSG("  DIR  %s\r\n", fileInfo.fname);
            totalDirs++;
        } else {
            APP_DBG_MSG("  FILE %s\r\n", fileInfo.fname);
            totalFiles++;
        }
    }

    APP_DBG_MSG("(total: %lu dirs, %lu files)\r\n--------\r\n", totalDirs, totalFiles);

    res = f_closedir(&dir);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_closedir() failed, res = %d\r\n", res);
        return;
    }

    APP_DBG_MSG("Writing to linky.txt...\r\n");

    char writeBuff[128];
    APP_DBG_MSG(writeBuff, sizeof(writeBuff), "Total blocks: %lu (%lu Mb); Free blocks: %lu (%lu Mb)\r\n",
        totalBlocks, totalBlocks / 2000,
        freeBlocks, freeBlocks / 2000);

    FIL logFile;
    res = f_open(&logFile, "linky.txt", FA_OPEN_APPEND | FA_WRITE);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_open() failed, res = %d\r\n", res);
        return;
    }

    unsigned int bytesToWrite = strlen(MyRxBuff);
    unsigned int bytesWritten;
    res = f_write(&logFile, MyRxBuff, bytesToWrite, &bytesWritten);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_write() failed, res = %d\r\n", res);
        return;
    }

    if(bytesWritten < bytesToWrite) {
        APP_DBG_MSG("WARNING! Disk is full, bytesToWrite = %u, bytesWritten = %u\r\n", bytesToWrite, bytesWritten);
    }

    res = f_close(&logFile);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_close() failed, res = %d\r\n", res);
        return;
    }

    APP_DBG_MSG("Reading file...\r\n");
    FIL msgFile;
    res = f_open(&msgFile, "linky.txt", FA_READ);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_open() failed, res = %d\r\n", res);
        return;
    }

    char readBuff[128];
    unsigned int bytesRead;
    res = f_read(&msgFile, readBuff, sizeof(readBuff)-1, &bytesRead);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_read() failed, res = %d\r\n", res);
        return;
    }

    readBuff[bytesRead] = '\0';
    APP_DBG_MSG("```\r\n%s\r\n```\r\n", readBuff);

    res = f_close(&msgFile);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("f_close() failed, res = %d\r\n", res);
        return;
    }

    // Unmount
    res = f_mount(NULL, "", 0);
    if(res != FR_OK) {
    	SD_ERROR_Check(res);
        APP_DBG_MSG("Unmount failed, res = %d\r\n", res);
        return;
    }

    APP_DBG_MSG("Done!\r\n");
}
*/
int Disable_SD_CS(void)
{
	HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_SET);
	return 0;
}
int Enable_SD_CS(void)
{
	HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_RESET);
	return 0 ;
}

void BeginNotification (void)
{
	HAL_TIM_Base_Start_IT(&htim17);
	char *msg = "C3: start notification !\n\r";
	HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 0x100);
	htim17.Instance->DIER=1; //UIE 1
	HAL_TIM_Base_Start(&htim17);

	//htim17->Instance->SR=1; //UIF 1
}

void FinishNotification(void)
{
	char *msg = "C3: stop notification !\n\r";
	HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 0x100);
	HAL_TIM_Base_Stop(&htim17);
	//HAL_TIM_Base_Stop_IT(&htim17);
}

char* increment_hour(char* hour) {
    if (strncmp(hour + 4, "59", 2) == 0) {
        hour[4] = '0';
        hour[5] = '0';

        if (strncmp(hour + 2, "59", 2) == 0) {
            hour[ 2] = '0';
            hour[3] = '0';

            if (strncmp(hour, "59", 2) == 0) {
            hour[0] = '0';
            hour[1] = '0';
            }else{
                if(strncmp(hour + 1, "9", 1) == 0){
                    hour[1] = '0';
                    hour[0] = (char)((int)hour[0] + 1);

                }else{
                    hour[1] = (char)((int)hour[1] + 1);
                }
            }
        }else{
            if(strncmp(hour + 3, "9", 1) == 0){
            hour[3] = '0';
            hour[ 2] = (char)((int)hour[ 2] + 1);

            }else{
                hour[3] = (char)((int)hour[3] + 1);
            }
        }
    }else{
        if(strncmp(hour + 5, "9", 1) == 0){
            hour[5] = '0';
            hour[4] = (char)((int)hour[4] + 1);

        }else{
            hour[5] = (char)((int)hour[5] + 1);
        }
    }

    return hour;
}



void EmulationHour(uint8_t* hour,int sizehour){
        if(hour[sizehour - 1] != 59) hour[sizehour - 1] = hour[sizehour - 1] +1;
        else{
            hour[sizehour - 1] = 00;

            if (hour[sizehour - 2] != 59) hour[sizehour - 2]= hour[sizehour - 2] + 1 ;
            else{
                hour[sizehour - 2] = 00;
                if (hour[sizehour - 3] != 23) hour[sizehour - 3] =+1;
                else hour[sizehour - 3] = 00;
           }
        }
}

void TimerIRQ(void)
{
	char *msg = "Timer 17 IRQ!\n\r";

	HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), 0x100);
	Toggle_LED('R');
	EmulationHour(TimerCount, sizeof(TimerCount));
	C3_NOTIFICATION(TimerCount,sizeof(TimerCount));
		// UTIL_SEQ_SetTask(1<<CFG_TASK_MY_ACTION,CFG_SCH_PRIO_0);//HW semaphore
}

HAL_StatusTypeDef SendUART(const unsigned char * buf, size_t bufSize)
{
	HAL_StatusTypeDef UART_error;

	 //UART_error=HAL_UART_Transmit(&huart1, (uint8_t*)buf, strlen(msg), 0x100);
	UART_error=HAL_UART_Transmit(&huart1, (uint8_t*)buf, bufSize, 0x100);

	 return UART_error;
}

int __io_putchar(int ch)
{
// uint8_t c[1];
// c[0] = ch & 0x00FF;
// HAL_UART_Transmit(&huart1, &*c, 1, 10);
HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0x10);
 return ch;
}
void Clear_LED(char data)
{
	switch(data){

	case 'R' :
		HAL_GPIO_WritePin(Red_LED_GPIO_Port, Red_LED_Pin, GPIO_PIN_RESET);
		break;

	case 'B' :
		HAL_GPIO_WritePin(Blue_LED_GPIO_Port, Blue_LED_Pin, GPIO_PIN_RESET);
		break;

	case 'G' :
		HAL_GPIO_WritePin(Green_LED_GPIO_Port, Green_LED_Pin, GPIO_PIN_RESET);
		break;

	case 'A' :
		HAL_GPIO_WritePin(Green_LED_GPIO_Port, Green_LED_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(Blue_LED_GPIO_Port, Blue_LED_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(Red_LED_GPIO_Port, Red_LED_Pin, GPIO_PIN_RESET);
		break;

	default :
		break;

				}
}

void Set_LED(char data)
{
	switch(data){

	case 'R' :
		HAL_GPIO_WritePin(Red_LED_GPIO_Port, Red_LED_Pin, GPIO_PIN_SET);
		break;

	case 'B' :
		HAL_GPIO_WritePin(Blue_LED_GPIO_Port, Blue_LED_Pin, GPIO_PIN_SET);
		break;

	case 'G' :
		HAL_GPIO_WritePin(Green_LED_GPIO_Port, Green_LED_Pin, GPIO_PIN_SET);
		break;

	case 'A' :
		HAL_GPIO_WritePin(Green_LED_GPIO_Port, Green_LED_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(Blue_LED_GPIO_Port, Blue_LED_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(Red_LED_GPIO_Port, Red_LED_Pin, GPIO_PIN_SET);
		break;

	default :
		break;

				}
}

void Toggle_LED(char data)
{
	switch(data){

	case 'R' :
		HAL_GPIO_TogglePin(Red_LED_GPIO_Port, Red_LED_Pin);
		break;

	case 'B' :
		HAL_GPIO_TogglePin(Blue_LED_GPIO_Port, Blue_LED_Pin);
		break;

	case 'G' :
		HAL_GPIO_TogglePin(Green_LED_GPIO_Port, Green_LED_Pin);
		break;

	case 'A' :
		HAL_GPIO_TogglePin(Green_LED_GPIO_Port, Green_LED_Pin);
		HAL_GPIO_TogglePin(Blue_LED_GPIO_Port, Blue_LED_Pin);
		HAL_GPIO_TogglePin(Red_LED_GPIO_Port, Red_LED_Pin);
		break;

	default :
		break;

				}
}



//}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: APP_DBG_MSG("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
