/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    App/custom_stm.c
  * @author  MCD Application Team
  * @brief   Custom Example Service.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "common_blesvc.h"
#include "custom_stm.h"

/* USER CODE BEGIN Includes */
int Custom_Updated_Characteristic1;
int Custom_Updated_Characteristic2;
int Custom_Updated_Characteristic3;
int Custom_Updated_Characteristic4;
Custom_STM_Data_t Custom_Characteristic1;
Custom_STM_Data_t Custom_Characteristic2;
Custom_STM_Data_t Custom_Characteristic3;
Custom_STM_Data_t Custom_Characteristic4;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef struct{
  uint16_t  CustomMyservHdle;                    /**< MyServ handle */
  uint16_t  CustomS1_Char1Hdle;                  /**< S1_CHAR1 handle */
  uint16_t  CustomS1_Char2Hdle;                  /**< S1_CHAR2 handle */
  uint16_t  CustomS1_Char3Hdle;                  /**< S1_CHAR3 handle */
  uint16_t  CustomS1_Char4Hdle;                  /**< S1_CHAR4 handle */
}CustomContext_t;

/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private defines -----------------------------------------------------------*/
#define UUID_128_SUPPORTED  1

#if (UUID_128_SUPPORTED == 1)
#define BM_UUID_LENGTH  UUID_TYPE_128
#else
#define BM_UUID_LENGTH  UUID_TYPE_16
#endif

#define BM_REQ_CHAR_SIZE    (3)

/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macros ------------------------------------------------------------*/
#define CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET         2
#define CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET              1
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
uint8_t SizeS1_Char1 = 26;
uint8_t SizeS1_Char2 = 26;
uint8_t SizeS1_Char3 = 26;
uint8_t SizeS1_Char4 = 26;

/**
 * START of Section BLE_DRIVER_CONTEXT
 */
static CustomContext_t CustomContext;

/**
 * END of Section BLE_DRIVER_CONTEXT
 */

/* USER CODE BEGIN PV */
typedef enum{
	INFO_LINKY = 0x01,
	INFO_MACHINE = 0x02,
	INFO_EAU = 0x03
}Caract1;

//(0x01)hex = 1(uint8_t)   (0x30)hex = 48(uint8_t)

uint8_t Carac1[] = {1,2,48};

typedef enum{
	OK            = 0x01,
	KO            = 0x02,
	BUSSY         = 0x03,
	ACK           = 0x04,
	WAIT_NOTIF1   = 0x10,
	WAIT_NOTIF2   = 0x20,
	WAIT_NOTIF3   = 0x30,
	WAIT_NOTIF4   = 0x40,
	READ_CARACT1  = 0x11,
	READ_CARACT2  = 0x21,
	READ_CARACT3  = 0x31,
	READ_CARACT4  = 0x41,
	WRITE_CARACT1 = 0x12,
	WRITE_CARACT2 = 0x22,
	WRITE_CARACT3 = 0x32,
	WRITE_CARACT4 = 0x42
}Carat3;

uint8_t Carac3[] = {1,2,3,4,
					16,32,48,64,
					17,33,49,65,
					18,34,50,66};

//On émule ses données, car entrain de gérer la gestion des données dans les fichiers de la carte sD
uint8_t EmulationDataLinky[15]  = {23,04,05,12,12,12,0,0,0,0,0,4,9,6,7} ; //une trame = 000004967
uint8_t EmulationDataMachine[7] = {23,04,05,12,12,12,0} ; //1 pour anomalie, 0 si OK
uint8_t EmulationDataTuyau[7]   = {23,04,05,12,12,12,1} ; //1 pour anomalie, 0 si OK

uint8_t* Statut;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
static SVCCTL_EvtAckStatus_t Custom_STM_Event_Handler(void *pckt);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Functions Definition ------------------------------------------------------*/
/* USER CODE BEGIN PFD */

/* USER CODE END PFD */

/* Private functions ----------------------------------------------------------*/

#define COPY_UUID_128(uuid_struct, uuid_15, uuid_14, uuid_13, uuid_12, uuid_11, uuid_10, uuid_9, uuid_8, uuid_7, uuid_6, uuid_5, uuid_4, uuid_3, uuid_2, uuid_1, uuid_0) \
do {\
    uuid_struct[0] = uuid_0; uuid_struct[1] = uuid_1; uuid_struct[2] = uuid_2; uuid_struct[3] = uuid_3; \
    uuid_struct[4] = uuid_4; uuid_struct[5] = uuid_5; uuid_struct[6] = uuid_6; uuid_struct[7] = uuid_7; \
    uuid_struct[8] = uuid_8; uuid_struct[9] = uuid_9; uuid_struct[10] = uuid_10; uuid_struct[11] = uuid_11; \
    uuid_struct[12] = uuid_12; uuid_struct[13] = uuid_13; uuid_struct[14] = uuid_14; uuid_struct[15] = uuid_15; \
}while(0)

/* Hardware Characteristics Service */
/*
 The following 128bits UUIDs have been generated from the random UUID
 generator:
 D973F2E0-B19E-11E2-9E96-0800200C9A66: Service 128bits UUID
 D973F2E1-B19E-11E2-9E96-0800200C9A66: Characteristic_1 128bits UUID
 D973F2E2-B19E-11E2-9E96-0800200C9A66: Characteristic_2 128bits UUID
 */
#define COPY_MYSERV_UUID(uuid_struct)          COPY_UUID_128(uuid_struct,0x00,0x00,0xab,0xcd,0xcc,0x7a,0x48,0x2a,0x98,0x4a,0x7f,0x2e,0xd5,0xb3,0xe5,0x8f)
#define COPY_S1_CHAR1_UUID(uuid_struct)    COPY_UUID_128(uuid_struct,0x00,0x00,0xbe,0xef,0x8e,0x22,0x45,0x41,0x9d,0x4c,0x21,0xed,0xae,0x82,0xed,0x19)
#define COPY_S1_CHAR2_UUID(uuid_struct)    COPY_UUID_128(uuid_struct,0x00,0x00,0xfe,0xed,0x8e,0x22,0x45,0x41,0x9d,0x4c,0x21,0xed,0xae,0x82,0xed,0x19)
#define COPY_S1_CHAR3_UUID(uuid_struct)    COPY_UUID_128(uuid_struct,0x00,0x00,0xaa,0xbb,0x8e,0x22,0x45,0x41,0x9d,0x4c,0x21,0xed,0xae,0x82,0xed,0x19)
#define COPY_S1_CHAR4_UUID(uuid_struct)    COPY_UUID_128(uuid_struct,0x00,0x00,0xcc,0xdd,0x8e,0x22,0x45,0x41,0x9d,0x4c,0x21,0xed,0xae,0x82,0xed,0x19)

/* USER CODE BEGIN PF */


void SEND_MES_BLESTATUS(tBleStatus Status)
{

	APP_DBG_MSG("\r\n\r */*/*/*/ ");

	switch(Status){

	case BLE_STATUS_SUCCESS :
			APP_DBG_MSG("\r\n\r BLE_STATUS_SUCCESS ");
	break;

	/*case BLE_STATUS_UNKNOWN_CONNECTION_ID :
			APP_DBG_MSG("\r\n\r BLE_STATUS_UNKNOWN_CONNECTION_ID ");
	break;*/

	case BLE_STATUS_FAILED :
			APP_DBG_MSG("\r\n\r BLE_STATUS_FAILED ");
	break;

	case BLE_STATUS_INVALID_PARAMS :
			APP_DBG_MSG("\r\n\r BLE_STATUS_INVALID_PARAMS ");
	break;

	case BLE_STATUS_BUSY :
			APP_DBG_MSG("\r\n\r BLE_STATUS_BUSY ");
	break;

	case BLE_STATUS_PENDING :
			APP_DBG_MSG("\r\n\r BLE_STATUS_PENDING ");
	break;

	/*case BLE_STATUS_NOT_ALLOWED :
			APP_DBG_MSG("\r\n\r BLE_STATUS_NOT_ALLOWED ");
	break;*/

	case BLE_STATUS_ERROR :
			APP_DBG_MSG("\r\n\r BLE_STATUS_ERROR ");
	break;

	case BLE_STATUS_OUT_OF_MEMORY :
			APP_DBG_MSG("\r\n\r BLE_STATUS_OUT_OF_MEMORY ");
	break;

	/*case BLE_STATUS_INVALID_CID :
			APP_DBG_MSG("\r\n\r BLE_STATUS_INVALID_CID ");
	break;*/

	case BLE_STATUS_DEV_IN_BLACKLIST :
			APP_DBG_MSG("\r\n\r BLE_STATUS_DEV_IN_BLACKLIST ");
	break;

	case BLE_STATUS_DEV_NOT_BONDED :
			APP_DBG_MSG("\r\n\r BLE_STATUS_DEV_NOT_BONDED ");
	break;

	case BLE_STATUS_CSRK_NOT_FOUND :
			APP_DBG_MSG("\r\n\r BLE_STATUS_CSRK_NOT_FOUND ");
	break;

	case BLE_STATUS_IRK_NOT_FOUND :
			APP_DBG_MSG("\r\n\r BLE_STATUS_IRK_NOT_FOUND ");
	break;

	case BLE_STATUS_INSUFFICIENT_ENC_KEYSIZE :
			APP_DBG_MSG("\r\n\r BLE_STATUS_INSUFFICIENT_ENC_KEYSIZE ");
	break;

	case BLE_STATUS_SEC_DB_FULL :
			APP_DBG_MSG("\r\n\r BLE_STATUS_SEC_DB_FULL ");
	break;

	case BLE_STATUS_INVALID_HANDLE :
			APP_DBG_MSG("\r\n\r BLE_STATUS_INVALID_HANDLE ");
	break;

	case BLE_STATUS_OUT_OF_HANDLE :
			APP_DBG_MSG("\r\n\r BLE_STATUS_OUT_OF_HANDLE ");
	break;

	case BLE_STATUS_INVALID_OPERATION :
			APP_DBG_MSG("\r\n\r BLE_STATUS_INVALID_OPERATION ");
	break;

	case BLE_STATUS_CHARAC_ALREADY_EXISTS :
			APP_DBG_MSG("\r\n\r BLE_STATUS_CHARAC_ALREADY_EXISTS ");
	break;

	case BLE_STATUS_INSUFFICIENT_RESOURCES :
			APP_DBG_MSG("\r\n\r BLE_STATUS_INSUFFICIENT_RESOURCES ");
	break;

	case BLE_STATUS_SEC_PERMISSION_ERROR :
			APP_DBG_MSG("\r\n\r BLE_STATUS_SEC_PERMISSION_ERROR ");
	break;

	case BLE_STATUS_ADDRESS_NOT_RESOLVED :
			APP_DBG_MSG("\r\n\r BLE_STATUS_ADDRESS_NOT_RESOLVED ");
	break;

	case BLE_STATUS_NO_VALID_SLOT :
			APP_DBG_MSG("\r\n\r BLE_STATUS_NO_VALID_SLOT ");
	break;

	case BLE_STATUS_SCAN_WINDOW_SHORT :
			APP_DBG_MSG("\r\n\r BLE_STATUS_SCAN_WINDOW_SHORT ");
	break;

	case BLE_STATUS_NEW_INTERVAL_FAILED :
			APP_DBG_MSG("\r\n\r BLE_STATUS_NEW_INTERVAL_FAILED ");
	break;

	case BLE_STATUS_TIMEOUT :
			APP_DBG_MSG("\r\n\r BLE_STATUS_TIMEOUT ");
	break;

	case BLE_STATUS_LENGTH_FAILED :
			APP_DBG_MSG("\r\n\r BLE_STATUS_LENGTH_FAILED ");
	break;

	case BLE_STATUS_INTERVAL_TOO_LARGE :
			APP_DBG_MSG("\r\n\r BLE_STATUS_INTERVAL_TOO_LARGE ");
	break;

	default :
		APP_DBG_MSG("\r\n\r Unknow error ");
	break;
	}

	APP_DBG_MSG("\r\n\r */*/*/*/ ");
}
void MirrorToC2(uint8_t *pPayload,uint8_t Length)
{
	Custom_Characteristic2.pPayload=pPayload;
	Custom_Characteristic2.Length=Length;
	Custom_Updated_Characteristic2=1;
	Ask_My_Action();
}

void WhatWantMobile(uint8_t *pPayload,uint8_t Length){
	  switch (pPayload[Length - 1]) {
	      case 0x01 :
	          // Afficher les informations du fichier linky
	    	  C3_NOTIFICATION(&Carac3[1],sizeof(Carac3[1]));
	    	  C3_NOTIFICATION(&Carac3[6],sizeof(Carac3[6]));
	    	  C2_NOTIFICATION(EmulationDataLinky,sizeof(EmulationDataLinky));
	    	  C3_NOTIFICATION(&Carac3[1],sizeof(Carac3[1]));

	          break;

	      case 0x02 :
	          // Afficher les informations du fichier machine
	    	  C3_NOTIFICATION(&Carac3[1],sizeof(Carac3[1]));
	    	  C3_NOTIFICATION(&Carac3[6],sizeof(Carac3[6]));
	    	  C2_NOTIFICATION(EmulationDataMachine,sizeof(EmulationDataMachine));
	    	  C3_NOTIFICATION(&Carac3[1],sizeof(Carac3[1]));
	    	  break;

	      case 0x03 :
	          // Afficher les informations du fichier eau
	    	  C3_NOTIFICATION(&Carac3[1],sizeof(Carac3[1]));
	    	  C3_NOTIFICATION(&Carac3[6],sizeof(Carac3[6]));
	    	  C2_NOTIFICATION(EmulationDataTuyau,sizeof(EmulationDataTuyau));
	    	  C3_NOTIFICATION(&Carac3[1],sizeof(Carac3[1]));
	          break;

	      default:
	          // Option invalide
	          break;
	  }
}

void C1_NOTIFICATION(uint8_t *pPayload,uint8_t Size)
{
	APP_DBG_MSG("\r\n\r C1_NOTIFICATION : update char\n");

	Custom_Characteristic1.pPayload = pPayload;
	Custom_Characteristic1.Length = Size;
	Custom_Updated_Characteristic1 = 1;

    Ask_My_Action();
}
void C2_NOTIFICATION(uint8_t *pPayload,uint8_t Size)
{

	APP_DBG_MSG("\r\n\r C2_NOTIFICATION : update char\n");

	Custom_Characteristic2.pPayload = pPayload;
	Custom_Characteristic2.Length = Size;
	Custom_Updated_Characteristic2 = 1;

    Ask_My_Action();
}

void C3_NOTIFICATION(uint8_t *pPayload,uint8_t Size)
{

	APP_DBG_MSG("\r\n\r C3_NOTIFICATION : update char\n");

	Custom_Characteristic3.pPayload = pPayload;
	Custom_Characteristic3.Length = Size;
	Custom_Updated_Characteristic3 = 1;

    Ask_My_Action();
}

void C4_NOTIFICATION(uint8_t *pPayload,uint8_t Size)
{
	 APP_DBG_MSG("\r\n\r C4_NOTIFICATION : update char\n");

	Custom_Characteristic4.pPayload = pPayload;
	Custom_Characteristic4.Length = Size;
	Custom_Updated_Characteristic4 = 1;

    Ask_My_Action();
}

tBleStatus Custom_Characteristic_Send(Custom_STM_Char_Opcode_t CharOpcode, uint8_t *pPayload,uint8_t Length,uint8_t Offset)
{
  tBleStatus result = BLE_STATUS_INVALID_PARAMS;
  /* USER CODE BEGIN Custom_STM_App_Update_Char_1 */
  APP_DBG_MSG("\r\n\r Welcome to Custom_Characteristic_Send \n");
  /* USER CODE END Custom_STM_App_Update_Char_1 */

  switch(CharOpcode)
  {
    case CUSTOM_STM_S1_CHAR1:
      result = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                          CustomContext.CustomS1_Char1Hdle,
										  Offset, /* charValOffset */
										  Length, /* charValueLen */
                                          (uint8_t *)  pPayload);
      /* USER CODE BEGIN CUSTOM_STM_Service_3_Char_1*/
      SEND_MES_BLESTATUS(result);
      /* USER CODE END CUSTOM_STM_Service_3_Char_1*/
      break;

    case CUSTOM_STM_S1_CHAR2:
      result = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                          CustomContext.CustomS1_Char2Hdle,
										  Offset, /* charValOffset */
										  Length, /* charValueLen */
                                          (uint8_t *)  pPayload);
      /* USER CODE BEGIN CUSTOM_STM_Service_3_Char_2*/
      APP_DBG_MSG("\r\n\r Entry CUSTOM_STM_Service_3_Char_2\n");
      SEND_MES_BLESTATUS(result);
      /* USER CODE END CUSTOM_STM_Service_3_Char_2*/
      break;

    case CUSTOM_STM_S1_CHAR3:
      result = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                          CustomContext.CustomS1_Char3Hdle,
										  Offset, /* charValOffset */
										  Length, /* charValueLen */
                                          (uint8_t *)  pPayload);


      /* USER CODE BEGIN CUSTOM_STM_Service_3_Char_3*/
	            APP_DBG_MSG("\r\n\r Entry CUSTOM_STM_Service_3_Char_3\n");
	            SEND_MES_BLESTATUS(result);
      /* USER CODE END CUSTOM_STM_Service_3_Char_3*/
      break;

    case CUSTOM_STM_S1_CHAR4:
      result = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                          CustomContext.CustomS1_Char4Hdle,
										  Offset, /* charValOffset */
										  Length, /* charValueLen */
                                          (uint8_t *)  pPayload);
      /* USER CODE BEGIN CUSTOM_STM_Service_3_Char_3*/
	            APP_DBG_MSG("\r\n\r Entry CUSTOM_STM_Service_3_Char_3\n");
	            SEND_MES_BLESTATUS(result);
      /* USER CODE END CUSTOM_STM_Service_3_Char_3*/
      break;


    default:
      break;
  }

  /* USER CODE BEGIN Custom_STM_App_Update_Char_2 */

  /* USER CODE END Custom_STM_App_Update_Char_2 */

  return result;
}

/**
 * @brief Vérifie que les caractéristiques sont mise à jour et envoie la mise à jour
 */
void My_Action(void)
{
	  APP_DBG_MSG("Welcome to My action\n");
	  if(Custom_Updated_Characteristic1==1)
	  	  {
		  APP_DBG_MSG("Custom_Characteristic 1 legnth : %d\n",Custom_Characteristic1.Length);
		  //Custom_STM_App_Update_Char(CUSTOM_STM_C1, Custom_Characteristic1.pPayload);
		  Custom_Characteristic_Send(CUSTOM_STM_S1_CHAR1, Custom_Characteristic1.pPayload,Custom_Characteristic1.Length,0);
		  Custom_Updated_Characteristic1=0;
	  	  }
	  if(Custom_Updated_Characteristic2==1)
	 	  {
	 		  APP_DBG_MSG("Custom_Characteristic 2 legnth : %d\n",Custom_Characteristic2.Length);
	 		 Custom_Characteristic_Send(CUSTOM_STM_S1_CHAR2, Custom_Characteristic2.pPayload,Custom_Characteristic2.Length,0);
	 		 Custom_Updated_Characteristic2=0;
	 	  }
	  if(Custom_Updated_Characteristic3==1)
	 	  {
	 		  APP_DBG_MSG("Custom_Characteristic 3 legnth : %d\n",Custom_Characteristic3.Length);
	 		  Custom_Characteristic_Send(CUSTOM_STM_S1_CHAR3, Custom_Characteristic3.pPayload,Custom_Characteristic3.Length,0);
	 		  Custom_Updated_Characteristic3=0;
	 	  }
	  if(Custom_Updated_Characteristic4==1)
	 	  {
	 		  APP_DBG_MSG("Custom_Characteristic 4 legnth : %d\n",Custom_Characteristic3.Length);
	 		  Custom_Characteristic_Send(CUSTOM_STM_S1_CHAR4, Custom_Characteristic3.pPayload,Custom_Characteristic3.Length,0);
	 		  Custom_Updated_Characteristic3=0;
	 	  }
}
/*
 * @brief Pour gérer les différentes tâches
 */
void Ask_My_Action(void)
{
	  APP_DBG_MSG("Ask for My action/n");
	  UTIL_SEQ_SetTask(1<<CFG_TASK_MY_ACTION,CFG_SCH_PRIO_0);//HW semaphore
}

/* USER CODE END PF */

/**
 * @brief  Event handler
 * @param  Event: Address of the buffer holding the Event
 * @retval Ack: Return whether the Event has been managed or not
 */
static SVCCTL_EvtAckStatus_t Custom_STM_Event_Handler(void *Event)
{
  SVCCTL_EvtAckStatus_t return_value;
  hci_event_pckt *event_pckt;
  evt_blecore_aci *blecore_evt;
  aci_gatt_attribute_modified_event_rp0 *attribute_modified;
  Custom_STM_App_Notification_evt_t     Notification;
  /* USER CODE BEGIN Custom_STM_Event_Handler_1 */
  APP_DBG_MSG("Custom_STM_Event_Handler_1/n");
  /* USER CODE END Custom_STM_Event_Handler_1 */

  return_value = SVCCTL_EvtNotAck;
  event_pckt = (hci_event_pckt *)(((hci_uart_pckt*)Event)->data);

  switch (event_pckt->evt)
  {
    case HCI_VENDOR_SPECIFIC_DEBUG_EVT_CODE:
      blecore_evt = (evt_blecore_aci*)event_pckt->data;
      switch (blecore_evt->ecode)
      {
        case ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE:
          /* USER CODE BEGIN EVT_BLUE_GATT_ATTRIBUTE_MODIFIED_BEGIN */

          /* USER CODE END EVT_BLUE_GATT_ATTRIBUTE_MODIFIED_BEGIN */
          attribute_modified = (aci_gatt_attribute_modified_event_rp0*)blecore_evt->data;
          if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char1Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1 */

            /* USER CODE END CUSTOM_STM_Service_1_Char_1 */
            switch (attribute_modified->Attr_Data[0])
            {
              /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1_attribute_modified */

              /* USER CODE END CUSTOM_STM_Service_1_Char_1_attribute_modified */

              /* Disabled Notification management */
              case (!(COMSVC_Notification)):
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1_Disabled_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_1_Disabled_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR1_NOTIFY_DISABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1_Disabled_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_1_Disabled_END */
                break;

              /* Enabled Notification management */
              case COMSVC_Notification:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1_COMSVC_Notification_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_1_COMSVC_Notification_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR1_NOTIFY_ENABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1_COMSVC_Notification_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_1_COMSVC_Notification_END */
                break;

              default:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1_default */

                /* USER CODE END CUSTOM_STM_Service_1_Char_1_default */
              break;
            }
          }  /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char1Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))*/

          else if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char2Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2 */

            /* USER CODE END CUSTOM_STM_Service_1_Char_2 */
            switch (attribute_modified->Attr_Data[0])
            {
              /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2_attribute_modified */

              /* USER CODE END CUSTOM_STM_Service_1_Char_2_attribute_modified */

              /* Disabled Notification management */
              case (!(COMSVC_Notification)):
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2_Disabled_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_2_Disabled_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR2_NOTIFY_DISABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2_Disabled_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_2_Disabled_END */
                break;

              /* Enabled Notification management */
              case COMSVC_Notification:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2_COMSVC_Notification_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_2_COMSVC_Notification_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR2_NOTIFY_ENABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2_COMSVC_Notification_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_2_COMSVC_Notification_END */
                break;

              default:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2_default */

                /* USER CODE END CUSTOM_STM_Service_1_Char_2_default */
              break;
            }
          }  /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char2Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))*/

          else if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char3Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3 */

            /* USER CODE END CUSTOM_STM_Service_1_Char_3 */
            switch (attribute_modified->Attr_Data[0])
            {
              /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3_attribute_modified */

              /* USER CODE END CUSTOM_STM_Service_1_Char_3_attribute_modified */

              /* Disabled Notification management */
              case (!(COMSVC_Notification)):
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3_Disabled_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_3_Disabled_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR3_NOTIFY_DISABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3_Disabled_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_3_Disabled_END */
                break;

              /* Enabled Notification management */
              case COMSVC_Notification:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3_COMSVC_Notification_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_3_COMSVC_Notification_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR3_NOTIFY_ENABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3_COMSVC_Notification_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_3_COMSVC_Notification_END */
                break;

              default:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3_default */

                /* USER CODE END CUSTOM_STM_Service_1_Char_3_default */
              break;
            }
          }  /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char3Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))*/

          else if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char4Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4 */

            /* USER CODE END CUSTOM_STM_Service_1_Char_4 */

            switch (attribute_modified->Attr_Data[0])
            {
              /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_attribute_modified  */

              /* USER CODE END CUSTOM_STM_Service_1_Char_4_attribute_modified  */

              /* Disabled Notification and Indication management */
              case (!(COMSVC_Notification) | !(COMSVC_Indication)):
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_Disabled_BEGIN  */

                /* USER CODE END CUSTOM_STM_Service_1_Char_4_Disabled_BEGIN  */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR4_NOTIFY_DISABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR4_INDICATE_DISABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_Disabled_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_4_Disabled_END */
                break;

              /* Enabled Notification management */
              case COMSVC_Notification:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_COMSVC_Notification_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_4_COMSVC_Notification_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR4_NOTIFY_ENABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_COMSVC_Notification_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_4_COMSVC_Notification_END */
                break;

              /* Enabled Indication management */
              case COMSVC_Indication:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_COMSVC_Indication_BEGIN */

                /* USER CODE END CUSTOM_STM_Service_1_Char_4_COMSVC_Indication_BEGIN */
                Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR4_INDICATE_ENABLED_EVT;
                Custom_STM_App_Notification(&Notification);
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_COMSVC_Indication_END */

                /* USER CODE END CUSTOM_STM_Service_1_Char_4_COMSVC_Indication_END */
                break;

              default:
                /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_default */

                /* USER CODE END CUSTOM_STM_Service_1_Char_4_default */
                break;
            }
          }  /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char4Hdle + CHARACTERISTIC_DESCRIPTOR_ATTRIBUTE_OFFSET))*/

          else if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char1Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_1_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
            APP_DBG_MSG("CUSTOM_STM_Service_1_Char_1_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE/n");
            APP_DBG_MSG("Tadaaaaa/n");
            Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR1_WRITE_NO_RESP_EVT;
			Notification.DataTransfered.Length=attribute_modified->Attr_Data_Length;
			Notification.DataTransfered.pPayload=attribute_modified->Attr_Data;
			Custom_STM_App_Notification(&Notification);
            /* USER CODE END CUSTOM_STM_Service_1_Char_1_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
          } /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char1Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))*/
          else if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char2Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_2_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
            APP_DBG_MSG("CUSTOM_STM_Service_1_Char_2_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE/n");
            Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR2_WRITE_NO_RESP_EVT;
			Notification.DataTransfered.Length=attribute_modified->Attr_Data_Length;
			Notification.DataTransfered.pPayload=attribute_modified->Attr_Data;
			Custom_STM_App_Notification(&Notification);
            /* USER CODE END CUSTOM_STM_Service_1_Char_2_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
          } /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char2Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))*/
          else if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char3Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_3_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
            APP_DBG_MSG("CUSTOM_STM_Service_1_Char_3_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE/n");
            Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR3_WRITE_NO_RESP_EVT;
			Notification.DataTransfered.Length=attribute_modified->Attr_Data_Length;
			Notification.DataTransfered.pPayload=attribute_modified->Attr_Data;
			Custom_STM_App_Notification(&Notification);
            /* USER CODE END CUSTOM_STM_Service_1_Char_3_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
          } /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char3Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))*/
          else if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char4Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))
          {
            return_value = SVCCTL_EvtAckFlowEnable;
            /* USER CODE BEGIN CUSTOM_STM_Service_1_Char_4_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
            APP_DBG_MSG("CUSTOM_STM_Service_1_Char_4_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE/n");
            Notification.Custom_Evt_Opcode = CUSTOM_STM_S1_CHAR4_WRITE_NO_RESP_EVT;
			Notification.DataTransfered.Length=attribute_modified->Attr_Data_Length;
			Notification.DataTransfered.pPayload=attribute_modified->Attr_Data;
			Custom_STM_App_Notification(&Notification);
            /* USER CODE END CUSTOM_STM_Service_1_Char_4_ACI_GATT_ATTRIBUTE_MODIFIED_VSEVT_CODE */
          } /* if (attribute_modified->Attr_Handle == (CustomContext.CustomS1_Char4Hdle + CHARACTERISTIC_VALUE_ATTRIBUTE_OFFSET))*/
          /* USER CODE BEGIN EVT_BLUE_GATT_ATTRIBUTE_MODIFIED_END */

          /* USER CODE END EVT_BLUE_GATT_ATTRIBUTE_MODIFIED_END */
          break;

        case ACI_GATT_READ_PERMIT_REQ_VSEVT_CODE :
          /* USER CODE BEGIN EVT_BLUE_GATT_READ_PERMIT_REQ_BEGIN */

          /* USER CODE END EVT_BLUE_GATT_READ_PERMIT_REQ_BEGIN */
          /* USER CODE BEGIN EVT_BLUE_GATT_READ_PERMIT_REQ_END */

          /* USER CODE END EVT_BLUE_GATT_READ_PERMIT_REQ_END */
          break;

        case ACI_GATT_WRITE_PERMIT_REQ_VSEVT_CODE:
          /* USER CODE BEGIN EVT_BLUE_GATT_WRITE_PERMIT_REQ_BEGIN */
        	  APP_DBG_MSG("EVT_BLUE_GATT_WRITE_PERMIT_REQ_BEGIN/n");
          /* USER CODE END EVT_BLUE_GATT_WRITE_PERMIT_REQ_BEGIN */
          /* USER CODE BEGIN EVT_BLUE_GATT_WRITE_PERMIT_REQ_END */

          /* USER CODE END EVT_BLUE_GATT_WRITE_PERMIT_REQ_END */
          break;
        /* USER CODE BEGIN BLECORE_EVT */

        /* USER CODE END BLECORE_EVT */
        default:
          /* USER CODE BEGIN EVT_DEFAULT */

          /* USER CODE END EVT_DEFAULT */
          break;
      }
      /* USER CODE BEGIN EVT_VENDOR*/

      /* USER CODE END EVT_VENDOR*/
      break; /* HCI_VENDOR_SPECIFIC_DEBUG_EVT_CODE */

      /* USER CODE BEGIN EVENT_PCKT_CASES*/

      /* USER CODE END EVENT_PCKT_CASES*/

    default:
      /* USER CODE BEGIN EVENT_PCKT*/

      /* USER CODE END EVENT_PCKT*/
      break;
  }

  /* USER CODE BEGIN Custom_STM_Event_Handler_2 */

  /* USER CODE END Custom_STM_Event_Handler_2 */

  return(return_value);
}/* end Custom_STM_Event_Handler */

/* Public functions ----------------------------------------------------------*/

/**
 * @brief  Service initialization
 * @param  None
 * @retval None
 */
void SVCCTL_InitCustomSvc(void)
{

  Char_UUID_t  uuid;
  tBleStatus ret = BLE_STATUS_INVALID_PARAMS;
  /* USER CODE BEGIN SVCCTL_InitCustomSvc_1 */

  /* USER CODE END SVCCTL_InitCustomSvc_1 */

  /**
   *  Register the event handler to the BLE controller
   */
  SVCCTL_RegisterSvcHandler(Custom_STM_Event_Handler);

  /**
   *          MyServ
   *
   * Max_Attribute_Records = 1 + 2*4 + 1*no_of_char_with_notify_or_indicate_property + 1*no_of_char_with_broadcast_property
   * service_max_attribute_record = 1 for MyServ +
   *                                2 for S1_CHAR1 +
   *                                2 for S1_CHAR2 +
   *                                2 for S1_CHAR3 +
   *                                2 for S1_CHAR4 +
   *                                1 for S1_CHAR1 configuration descriptor +
   *                                1 for S1_CHAR2 configuration descriptor +
   *                                1 for S1_CHAR3 configuration descriptor +
   *                                1 for S1_CHAR4 configuration descriptor +
   *                                1 for S1_CHAR4 broadcast property +
   *                              = 14
   */

  COPY_MYSERV_UUID(uuid.Char_UUID_128);
  ret = aci_gatt_add_service(UUID_TYPE_128,
                             (Service_UUID_t *) &uuid,
                             PRIMARY_SERVICE,
                             14,
                             &(CustomContext.CustomMyservHdle));
  if (ret != BLE_STATUS_SUCCESS)
  {
    APP_DBG_MSG("  Fail   : aci_gatt_add_service command: MyServ, error code: 0x%x \n\r", ret);
  }
  else
  {
    APP_DBG_MSG("  Success: aci_gatt_add_service command: MyServ \n\r");
  }

  /**
   *  S1_CHAR1
   */
  COPY_S1_CHAR1_UUID(uuid.Char_UUID_128);
  ret = aci_gatt_add_char(CustomContext.CustomMyservHdle,
                          UUID_TYPE_128, &uuid,
                          SizeS1_Char1,
                          CHAR_PROP_READ | CHAR_PROP_WRITE_WITHOUT_RESP | CHAR_PROP_NOTIFY,
                          ATTR_PERMISSION_NONE,
                          GATT_NOTIFY_ATTRIBUTE_WRITE,
                          0x10,
                          CHAR_VALUE_LEN_VARIABLE,
                          &(CustomContext.CustomS1_Char1Hdle));
  if (ret != BLE_STATUS_SUCCESS)
  {
    APP_DBG_MSG("  Fail   : aci_gatt_add_char command   : S1_CHAR1, error code: 0x%x \n\r", ret);
  }
  else
  {
    APP_DBG_MSG("  Success: aci_gatt_add_char command   : S1_CHAR1 \n\r");
  }
  /**
   *  S1_CHAR2
   */
  COPY_S1_CHAR2_UUID(uuid.Char_UUID_128);
  ret = aci_gatt_add_char(CustomContext.CustomMyservHdle,
                          UUID_TYPE_128, &uuid,
                          SizeS1_Char2,
                          CHAR_PROP_READ | CHAR_PROP_WRITE_WITHOUT_RESP | CHAR_PROP_NOTIFY,
                          ATTR_PERMISSION_NONE,
                          GATT_NOTIFY_ATTRIBUTE_WRITE,
                          0x10,
                          CHAR_VALUE_LEN_VARIABLE,
                          &(CustomContext.CustomS1_Char2Hdle));
  if (ret != BLE_STATUS_SUCCESS)
  {
    APP_DBG_MSG("  Fail   : aci_gatt_add_char command   : S1_CHAR2, error code: 0x%x \n\r", ret);
  }
  else
  {
    APP_DBG_MSG("  Success: aci_gatt_add_char command   : S1_CHAR2 \n\r");
  }
  /**
   *  S1_CHAR3
   */
  COPY_S1_CHAR3_UUID(uuid.Char_UUID_128);
  ret = aci_gatt_add_char(CustomContext.CustomMyservHdle,
                          UUID_TYPE_128, &uuid,
                          SizeS1_Char3,
                          CHAR_PROP_READ | CHAR_PROP_WRITE_WITHOUT_RESP | CHAR_PROP_NOTIFY,
                          ATTR_PERMISSION_NONE,
                          GATT_NOTIFY_ATTRIBUTE_WRITE,
                          0x10,
                          CHAR_VALUE_LEN_VARIABLE,
                          &(CustomContext.CustomS1_Char3Hdle));
  if (ret != BLE_STATUS_SUCCESS)
  {
    APP_DBG_MSG("  Fail   : aci_gatt_add_char command   : S1_CHAR3, error code: 0x%x \n\r", ret);
  }
  else
  {
    APP_DBG_MSG("  Success: aci_gatt_add_char command   : S1_CHAR3 \n\r");
  }
  /**
   *  S1_CHAR4
   */
  COPY_S1_CHAR4_UUID(uuid.Char_UUID_128);
  ret = aci_gatt_add_char(CustomContext.CustomMyservHdle,
                          UUID_TYPE_128, &uuid,
                          SizeS1_Char4,
                          CHAR_PROP_BROADCAST | CHAR_PROP_READ | CHAR_PROP_WRITE_WITHOUT_RESP | CHAR_PROP_NOTIFY | CHAR_PROP_INDICATE,
                          ATTR_PERMISSION_NONE,
                          GATT_NOTIFY_ATTRIBUTE_WRITE,
                          0x10,
                          CHAR_VALUE_LEN_VARIABLE,
                          &(CustomContext.CustomS1_Char4Hdle));
  if (ret != BLE_STATUS_SUCCESS)
  {
    APP_DBG_MSG("  Fail   : aci_gatt_add_char command   : S1_CHAR4, error code: 0x%x \n\r", ret);
  }
  else
  {
    APP_DBG_MSG("  Success: aci_gatt_add_char command   : S1_CHAR4 \n\r");
  }

  /* USER CODE BEGIN SVCCTL_InitCustomSvc_2 */

  /* USER CODE END SVCCTL_InitCustomSvc_2 */

  return;
}

/**
 * @brief  Characteristic update
 * @param  CharOpcode: Characteristic identifier
 * @param  Service_Instance: Instance of the service to which the characteristic belongs
 *
 */
tBleStatus Custom_STM_App_Update_Char(Custom_STM_Char_Opcode_t CharOpcode, uint8_t *pPayload)
{
  tBleStatus ret = BLE_STATUS_INVALID_PARAMS;
  /* USER CODE BEGIN Custom_STM_App_Update_Char_1 */
  APP_DBG_MSG("\r\n\r Welcome to Custom_Characteristic_Send \n");
  /* USER CODE END Custom_STM_App_Update_Char_1 */

  switch (CharOpcode)
  {

    case CUSTOM_STM_S1_CHAR1:
      ret = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                       CustomContext.CustomS1_Char1Hdle,
                                       0, /* charValOffset */
                                       SizeS1_Char1, /* charValueLen */
                                       (uint8_t *)  pPayload);
      if (ret != BLE_STATUS_SUCCESS)
      {
        APP_DBG_MSG("  Fail   : aci_gatt_update_char_value S1_CHAR1 command, result : 0x%x \n\r", ret);
      }
      else
      {
        APP_DBG_MSG("  Success: aci_gatt_update_char_value S1_CHAR1 command\n\r");
      }
      /* USER CODE BEGIN CUSTOM_STM_App_Update_Service_1_Char_1*/
      APP_DBG_MSG("\r\n\r CUSTOM_STM_App_Update_Service_1_Char_1 : update char\n");
      /* USER CODE END CUSTOM_STM_App_Update_Service_1_Char_1*/
      break;

    case CUSTOM_STM_S1_CHAR2:
      ret = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                       CustomContext.CustomS1_Char2Hdle,
                                       0, /* charValOffset */
                                       SizeS1_Char2, /* charValueLen */
                                       (uint8_t *)  pPayload);
      if (ret != BLE_STATUS_SUCCESS)
      {
        APP_DBG_MSG("  Fail   : aci_gatt_update_char_value S1_CHAR2 command, result : 0x%x \n\r", ret);
      }
      else
      {
        APP_DBG_MSG("  Success: aci_gatt_update_char_value S1_CHAR2 command\n\r");
      }
      /* USER CODE BEGIN CUSTOM_STM_App_Update_Service_1_Char_2*/
      APP_DBG_MSG("\r\n\r CUSTOM_STM_App_Update_Service_1_Char_2 : update char\n");
      /* USER CODE END CUSTOM_STM_App_Update_Service_1_Char_2*/
      break;

    case CUSTOM_STM_S1_CHAR3:
      ret = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                       CustomContext.CustomS1_Char3Hdle,
                                       0, /* charValOffset */
                                       SizeS1_Char3, /* charValueLen */
                                       (uint8_t *)  pPayload);
      if (ret != BLE_STATUS_SUCCESS)
      {
        APP_DBG_MSG("  Fail   : aci_gatt_update_char_value S1_CHAR3 command, result : 0x%x \n\r", ret);
      }
      else
      {
        APP_DBG_MSG("  Success: aci_gatt_update_char_value S1_CHAR3 command\n\r");
      }
      /* USER CODE BEGIN CUSTOM_STM_App_Update_Service_1_Char_3*/
      APP_DBG_MSG("\r\n\r CUSTOM_STM_App_Update_Service_1_Char_3 : update char\n");
      /* USER CODE END CUSTOM_STM_App_Update_Service_1_Char_3*/
      break;

    case CUSTOM_STM_S1_CHAR4:
      ret = aci_gatt_update_char_value(CustomContext.CustomMyservHdle,
                                       CustomContext.CustomS1_Char4Hdle,
                                       0, /* charValOffset */
                                       SizeS1_Char4, /* charValueLen */
                                       (uint8_t *)  pPayload);
      if (ret != BLE_STATUS_SUCCESS)
      {
        APP_DBG_MSG("  Fail   : aci_gatt_update_char_value S1_CHAR4 command, result : 0x%x \n\r", ret);
      }
      else
      {
        APP_DBG_MSG("  Success: aci_gatt_update_char_value S1_CHAR4 command\n\r");
      }
      /* USER CODE BEGIN CUSTOM_STM_App_Update_Service_1_Char_4*/
      APP_DBG_MSG("\r\n\r CUSTOM_STM_App_Update_Service_1_Char_4 : update char\n");
      /* USER CODE END CUSTOM_STM_App_Update_Service_1_Char_4*/
      break;

    default:
      break;
  }

  /* USER CODE BEGIN Custom_STM_App_Update_Char_2 */

  /* USER CODE END Custom_STM_App_Update_Char_2 */

  return ret;
}
