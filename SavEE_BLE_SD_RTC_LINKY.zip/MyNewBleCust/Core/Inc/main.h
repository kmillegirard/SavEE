/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32wbxx_hal.h"

#include "app_conf.h"
#include "app_entry.h"
#include "app_common.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "stdlib.h"
#include "dbg_trace.h"
#include "ble_types.h"
#include "custom_stm.h"

#define SD_SPI_HANDLE hspi1


/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */


//COMMAND FOR STATE SD
typedef enum {
    Cmd_GoIdleState          = 0x40, // CMD0 Go idle state.
    Cmd_SendOpCond           = 0x41, // CMD1 Send Op Condition
    Cmd_SwitchFunc           = 0x46, // CMD6 Check switchable function (mode 0) and swtches card function (mode 1)
    Cmd_SendIfCond           = 0x48, // CMD8 Verify SD Memory Card interface operating condition.
    Cmd_SendCSD              = 0x49, // CMD9 Ask to send the card specific data
    Cmd_SendCID              = 0x4A, // CMD10 Ask to send the card identification
    Cmd_StopTransmission     = 0x4C, // CMD11 Stop reading blocks.
    Cmd_SendStatus           = 0x4D, // CMD13 Ask to send the status
    Cmd_SetBlockLenght       = 0x50, // CMD16 Set the block length
    Cmd_ReadSingleBlock      = 0x51, // CMD17 Read one block.
    Cmd_ReadMultiBlock       = 0x52, // CMD18 Read multiple blocks.
    Cmd_SetBlockCount        = 0x53, // CMD23 Set block count
    Cmd_WriteSingleBlock     = 0x58, // CMD24 set address to write data
    Cmd_WriteMultiBlock      = 0x59, // CMD25 write multiple blocks
    Cmd_WriteCSD             = 0x5B, // CMD27 write CSD
    Cmd_EraseStartBlock      = 0x60, // CMD32 Address of the first write block to be erased
    Cmd_EraseEndBlock        = 0x61, // CMD33 Address of the last write block to be erased
    Cmd_Erase                = 0x66, // CMD38 Erase the define range
    Cmd_AppCmd               = 0x77, // CMD55 Defines to the card that the next cmd is an application specific cmd
    Cmd_GenCmd               = 0x78, // CMD56 transfert DATA block or get DATA block
    Cmd_ReadOCR              = 0x7A, // CMD58 Retrieve the OCR register.
    Cmd_CRCOnOff             = 0x7B, // CMD59 Turns the CRC On or off
    ACmd_SDStatus            = 0x4D, // ACMD13 Send the SD Status
    ACmd_SendOpCond          = 0x69  // ACMD41 Sends host capacity support information and activates the card's initialization process.
}SD_Command;

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);
void MX_USART1_UART_Init(void);

/* USER CODE BEGIN EFP */
void get_time(void);
void set_time(uint8_t Clock[7]);
void SDCard_Writting(uint8_t readBuf[]);
int Disable_SD_CS(void);
int Enable_SD_CS(void);
void SD_init_Fct (void);
char* increment_hour(char* hour) ;
//uint8_t char_to_uint8(char* new_hour);
void EmulationHour(uint8_t* hour,int sizehour);
void testSDCard();


void BeginNotification (void);
void FinishNotification(void);
void TimerIRQ(void);
HAL_StatusTypeDef SendUART(const unsigned char * buf, size_t bufSize);
void SEND_MES_BLESTATUS(tBleStatus Status);
void Toggle_LED(char data);
void Set_LED(char data);
void Clear_LED(char data);
HAL_StatusTypeDef SendUART(const unsigned char * buf, size_t bufSize);
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SD_CS_Pin GPIO_PIN_4
#define SD_CS_GPIO_Port GPIOA
#define B1_Pin GPIO_PIN_4
#define B1_GPIO_Port GPIOC
#define LD2_Pin GPIO_PIN_0
#define LD2_GPIO_Port GPIOB
#define LD3_Pin GPIO_PIN_1
#define LD3_GPIO_Port GPIOB
#define JTMS_Pin GPIO_PIN_13
#define JTMS_GPIO_Port GPIOA
#define JTCK_Pin GPIO_PIN_14
#define JTCK_GPIO_Port GPIOA
#define B2_Pin GPIO_PIN_0
#define B2_GPIO_Port GPIOD
#define B3_Pin GPIO_PIN_1
#define B3_GPIO_Port GPIOD
#define JTDO_Pin GPIO_PIN_3
#define JTDO_GPIO_Port GPIOB
#define LD1_Pin GPIO_PIN_5
#define LD1_GPIO_Port GPIOB
#define STLINK_RX_Pin GPIO_PIN_6
#define STLINK_RX_GPIO_Port GPIOB
#define STLINK_TX_Pin GPIO_PIN_7
#define STLINK_TX_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
#define Green_LED_Pin GPIO_PIN_0
#define Green_LED_GPIO_Port GPIOB
#define Red_LED_Pin GPIO_PIN_1
#define Red_LED_GPIO_Port GPIOB
#define Blue_LED_Pin GPIO_PIN_5
#define Blue_LED_GPIO_Port GPIOB
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
